﻿#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: MyAvimport.cs
//   VERSION: 0.5.1-beta
//     BUILD: 170212
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2018 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/* Main form for myAvatool.
 */
#endregion

#region USING
using Du;
using myAvimport.NTSTWEBSRV_ClientDischarge_SANDBOX;
using myAvimport.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
#endregion

namespace myAvimport
{
    public partial class MyAvimport : Form
    {
        /* ClientDischarge specific.
         */
        public ClientDischargeObject[]                   ClientDischargeObjects;
        public Dictionary<string, ClientDischargeObject> ClientDemographicData;

        /* General.
         */
        public int            CurrentLocation;
        public List<string>[] ImportedRecords;
        public int            CurrentRecord     = 0;
        public string         ImportType        = string.Empty;
        public string         SystemCode        = "SBOX";
        public bool           TestMode          = true;
        public bool           ThrottleImport    = true;

        /// <summary> Entry point for myAvimport. </summary>
        public MyAvimport()
        {
            InitializeComponent();

            /*  While myAvimport is split into three versions, we'll need to manually kick off the UI process. When the
             *  code is monolthic, this line will be removed because clicking on an environment radio button will start
             *  the process.
             */
            EnvironmentChanged();
        }

        /// <summary>
        /// User clicks the Import button.
        /// </summary>
        private void BtnImport_Click(object sender, EventArgs e)
        {
            switch (ImportType)
            {
                case "Demographics":
                    ClientDischarge.Import(ClientDemographicData, SystemCode, tbxUsername.Text, tbxPassword.Text, TestMode, ThrottleImport);
                    break;

                 default:
                    break;
            }
        }

        /// <summary>
        /// User checks/unchecks the TestMode checkbox
        /// </summary>
        private void CbxTestMode_CheckedChanged(object sender, EventArgs e)
        {
            TestMode = cbxTestMode.Checked;

            /*  While myAvimport is split into three versions, we'll need to manually kick off the UI process. When the
             *  code is monolthic, this line will be removed because clicking on an environment radio button will start
             *  the process.
             */
            EnvironmentChanged();
        }

        #region SET_INDICATORS

        /// <summary>
        /// Does various things with the UI.
        /// </summary>
        /// <param name = "phase"> Where the user is in the process.</param>
        private void SetIndicators(string phase)
        {

            if (phase.Contains("showErrors"))
            {
                lblIndicatorLoadData.BackColor = Color.Honeydew;

                switch (phase)
                {
                    case "showErrorsNone":
                        lblIndicatorPreview.BackColor = Color.Honeydew;
                        lblIndicatorErrors.BackColor  = Color.Gray;
                        lblIndicatorResolve.BackColor = Color.Gray;

                        if (!TestMode)
                        {
                            lblIndicatorImport.BackColor = Color.LightGreen;
                            btnImport.BackColor          = Color.SeaGreen;
                            btnImport.Enabled            = true;
                        }
                        else
                        {
                            lblIndicatorImport.BackColor = Color.Gray;
                        }

                        break;

                    case "showErrorsSome":
                        lblIndicatorResolve.BackColor = Color.LightGreen;
                        btnAcceptErrors.Enabled       = true;
                        btnCancelImport.Enabled       = true;
                        btnAcceptErrors.BackColor     = Color.SeaGreen;
                        btnCancelImport.BackColor     = Color.SeaGreen;

                        break;

                    default:

                        break;
                }
            }

            if (phase.Contains("LoadCEFE"))
            {
                btnLoadClientDemographicsData.BackColor               = Color.DarkSeaGreen;

                if (phase == "LoadCEFEComplete")
                {
                    lblIndicatorLoadData.BackColor = Color.Honeydew;
                    lblIndicatorPreview.BackColor  = Color.Honeydew;
                    lblIndicatorErrors.BackColor   = Color.Honeydew;
                }
            }

            if (phase.Contains("LoadDemographics"))
            {
                btnLoadClientDemographicsData.BackColor               = Color.DarkSeaGreen;

                if (phase == "LoadDemographicsComplete")
                {
                    lblIndicatorLoadData.BackColor = Color.Honeydew;
                    lblIndicatorPreview.BackColor  = Color.Honeydew;
                    lblIndicatorErrors.BackColor   = Color.Honeydew;
                }
            }

            if (phase == "LoginSuccess")
            {
                pnlLogin.Visible                                      = false;
                pnlLoggedIn.Visible                                   = true;
                lblLoggedInStatus.Text                                = "You are logged into " + SystemCode + " as " + tbxUsername.Text;
                lblIndicatorCredentials.BackColor                     = Color.Honeydew;
                lblIndicatorLoadData.BackColor                        = Color.LightGreen;
                btnLoadClientDemographicsData.Enabled                 = true;
                btnLoadClientDemographicsData.BackColor               = Color.SeaGreen;

            }

            if (phase.Contains("Environment"))
            {
                lblIndicatorCredentials.BackColor                     = Color.Gray;
                lblIndicatorChooseEnvironment.BackColor               = Color.Honeydew;
                lblIndicatorLoadData.BackColor                        = Color.LightGreen;
                btnLoadClientDemographicsData.Enabled                 = true;
                btnLoadClientDemographicsData.BackColor               = Color.SeaGreen;

                if (phase != "EnvironmentTestMode")
                {
                    lblIndicatorCredentials.BackColor       = Color.LightGreen;
                    lblIndicatorChooseEnvironment.BackColor = Color.Honeydew;
                    tbxUsername.Enabled                     = true;
                    tbxPassword.Enabled                     = true;
                }
            }

            if (phase == "AcceptErrors")
            {
                btnAcceptErrors.BackColor    = Color.DarkSeaGreen;
                btnCancelImport.BackColor    = Color.SeaGreen;
                lblIndicatorImport.BackColor = Color.LightGreen;
                btnImport.Enabled            = true;
                btnImport.BackColor          = Color.DarkSeaGreen;
            }
        }

        # endregion SET_INDICATORS

        #region RECORD_NAVIGATION
        /// <summary>
        /// User clicks the Previous Record button.
        /// </summary>
        private void BtnPreviousRecord_Click(object sender, EventArgs e)
        {
            PreviousRecord();
        }

        /// <summary>
        /// Navigte to the previous record.
        /// </summary>
        public void PreviousRecord()
        {
            CurrentLocation--;

            if (CurrentLocation < 0)
            {
                CurrentLocation = ImportedRecords.Length - 1;
            }

            lblClientRecordDisplay.Text = "Record " + (CurrentLocation + 1) + " of " + ImportedRecords.Length;

            UpdatePreview(ImportedRecords[CurrentLocation]);
        }

        /// <summary>
        /// User presses the next record button.
        /// </summary>
        private void BtnNextRecord_Click(object sender, EventArgs e)
        {
            NextRecord();
        }

        /// <summary>
        /// Advance to the next record.
        /// </summary>
        public void NextRecord()
        {
            CurrentLocation++;

            if (CurrentLocation > ImportedRecords.Length - 1)
            {
                CurrentLocation = 0;
            }

            lblClientRecordDisplay.Text = "Record " + (CurrentLocation + 1) + " of " + ImportedRecords.Length;

            UpdatePreview(ImportedRecords[CurrentLocation]);
        }
        #endregion RECORD_NAVIGATION

        #region ERRORS
        /// <summary>
        /// Show any errors.
        /// </summary>
        /// <param name = "errors"> The list of errors. </param>
        public void ShowErrors(List<string> errors)
        {
            foreach (var error in errors)
            {
                tbxErrors.Text = error + Environment.NewLine;
            }

            SetIndicators(!errors[0].Contains("No errors found")
                              ? "showErrorsSome"
                              : "showErrorsNone");
        }

        /// <summary>
        /// Clicks the Accept Errors button.
        /// </summary>
        private void BtnAcceptErrors_Click(object sender, EventArgs e)
        {
            SetIndicators("AcceptErrors");
        }

        private void BtnCancelImport_Click(object sender, EventArgs e)
        {
        }
        #endregion ERRORS

        #region PREVIEW
        /// <summary>
        /// Update data preview window.
        /// </summary>
        /// <param name = "content"> The message to display </param>
        public void UpdatePreview(string content)
        {
            tbxPreview.Text = content;
        }

        /// <summary>
        /// Update data preview window.
        /// </summary>
        /// <param name = "toShow"></param>
        public void UpdatePreview(List<string> toShow)
        {
            var previewData = string.Empty;

            foreach (var part in toShow)
            {
                previewData += part + Environment.NewLine;
            }

            tbxPreview.Text = previewData;
        }
        #endregion PREVIEW

        #region LOAD_DATA
  
        /// <summary>
        /// User requests to import a file containing client demographic data.
        /// </summary>
        private void BtnLoadClientDemographicsData_Click(object sender, EventArgs e)
        {
            SetIndicators("LoadDemographics");

            if (ofdFileToConvert.ShowDialog() == DialogResult.OK)
            {
                if (DuFile.CountLines(new StreamReader(ofdFileToConvert.FileName)) > 0)
                {
                    ImportType = "Demographics";

                    var fileAsString = DuFile.ToString(ofdFileToConvert.FileName);

                    ImportedRecords = DataConvert.FromFile(fileAsString);

                    if (ImportedRecords.Length != 0)
                    {
                        ClientDemographicData = ClientDischarge.CreateObjects(ImportedRecords);

                        var errorList = ClientDischarge.CheckForErrors(ClientDemographicData);

                        lblDescriptionDataPreview.Text = "ID\nLast Name\nFirst Name\nMiddle Name\nSex\nSocial Security Number\nEthnic Origin\nMarital Status\nDate Of Birth\nAddress Street 1\nAddress Street 2\nAddress Street City\nAddress Street State\nAddress Street Zipcode\nHome Phone\nWork Phone\nCell Phone\nVeteran\nRace\nPrimary Language\nSmoker\nSmoking Status Assessment Date\nEpisode Number\nProgram\nAdmission Date\nAttending Practitioner\nType Of Admission\nUTC Timestamp\n";

                        UpdatePreview(ImportedRecords[CurrentLocation]);
                        ShowErrors(errorList);
                    }

                    SetIndicators("LoadDemographicsComplete");
                }
                else
                {
                    DuMessageBox.Display("The import file is empty!", "myAvimport error...");
                }
            }
            else
            {
                DuMessageBox.Display("The import file cannot be found!", "myAvimport error...");
            }
        }
        #endregion LOAD_DATA

        #region ENVIRONMENTS
        /// <summary>
        /// Not used.
        /// </summary>
        private void RdoSBOX_CheckedChanged(object sender, EventArgs e)
        {
            EnvironmentChanged();
        }


        /// <summary>
        /// Not used.
        /// </summary>
        private string GetEnvironment()
        {
            if (rdoSBOX.Checked)
            {
                return "SBOX";
            }
            else
            {
                return "NONE";
            }
        }

        /// <summary> What? </summary>
        private void EnvironmentChanged()
        {
            /*  This isn't used while there are three versions.
             *
             */
            //SystemCode = GetEnvironment();
            SystemCode = "SBOX";

            if (SystemCode != "NONE" && !TestMode)
            {
                SetIndicators("Environment");
                CredentialsChanged();
            }
            else if (SystemCode != "NONE" && TestMode)
            {
                SetIndicators("EnvironmentTestMode");
            }
        }
        #endregion ENVIRONMENTS

        #region LOGIN
        /// <summary>
        /// Clicks lotin button.
        /// </summary>
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            var loggedInStatus = UserManagement.DoesUserExist(SystemCode, tbxUsername.Text, tbxPassword.Text);

            if (loggedInStatus.Contains("does exist"))
            {
                SetIndicators("LoginSuccess");
            }
            else
            {
                DuMessageBox.Display("Avatar username or password incorrect!", "myAvimport error...");
                tbxUsername.Text = string.Empty;
                tbxPassword.Text = string.Empty;
            }
        }

        /// <summary>
        /// Username field is changed.
        /// </summary>
        private void TbxUsername_TextChanged(object sender, EventArgs e)
        {
            CredentialsChanged();
        }

        /// <summary>
        /// Password field is changed.
        /// </summary>
        private void TbxPassword_TextChanged(object sender, EventArgs e)
        {
            CredentialsChanged();
        }

        /// <summary>
        /// Credentials changed.
        /// </summary>
        private void CredentialsChanged()
        {
            if (tbxUsername.Text != string.Empty && tbxPassword.Text != string.Empty)
            {
                btnLogin.Enabled         = true;
                btnLogin.BackgroundImage = Resources.icons8_login_32_green;
            }
            else
            {
                btnLogin.Enabled         = false;
                btnLogin.BackgroundImage = Resources.icons8_login_32;
            }
        }
        #endregion LOGIN
    }
}