*************************
*						*
* myAvatool: myAvimport *
*						*
*   	 README			*
*						*
*   February 13, 2018	*
*						*
*************************

* The source code for myAvatool: myAvimport is located in:

		\\ssmh-qdata\mis\myavatool\source.

* When extracting the source, you may need to do so to the root of your drive.
  Some of the Netsmart method names are long enough to exceed 256 characters.
  
* By default "Test Mode" is enabled. When using this mode, you are essentially
  "previewing" the data that you will import. Since you do not log into an
  environment (Test Mode prohibits this), no data can be imported. It is
  recommended that you use Test Mode to verify your data prior to importing.
  
* Test Mode must be disabled when myAvimport starts. If anything else gets
  focus prior to disabling Test Mode, you'll need to close and restart
  myAvimport. This isn't by design, I just didn't have time to put in a proper
  fix.
  
* By default "Throttle Import" is enabled. This introduces a small (50ms)
  pause between each record when importing. This causes the import to take
  longer, but (hopefully) doesn't overload Avatar with data.
  
* Each environment has it's own myAvimport application.

* When logging into myAvimport:

	1. Make sure you uncheck "Test Mode" as soon as myAvimport starts
	2. Once you have entered your username/password, click the green
	   arrow. Pressing "Enter" does not work.