﻿#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: ClientAdmission.cs
//   VERSION: 0.5.0-beta
//     BUILD: 180207
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2018 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/*  Contains all of the logic for working with the WEBSVC.ClientAdmission Web Service.
 */
#endregion

#region USING
using Du;
using myAvimport.NTSTWEBSRV_ClientAdmission_SBOX;
using myAvimport.NTSTWEBSRV_ClientDischarge_SBOX;
using System;
using System.Collections.Generic;
using System.Drawing;
#endregion

namespace myAvimport
{
    public class ClientAdmission
    {
        public string   ClientName                  { get; set; }
        public string   ClientLastName              { get; set; }
        public string   ClientFirstName             { get; set; }
        public string   ClientMiddleName            { get; set; }
        public string   Sex                         { get; set; }
        public string   SocialSecurityNumber        { get; set; }
        public string   EthnicOrigin                { get; set; }
        public string   MaritalStatus               { get; set; }
        public string   DateOfBirth                 { get; set; }
        public string   ClientAddressStreet         { get; set; }
        public string   ClientAddressStreet2        { get; set; }
        public string   ClientAddressCity           { get; set; }
        public string   ClientAddressState          { get; set; }
        public string   ClientAddressZipcode        { get; set; }
        public string   ClientHomePhone             { get; set; }
        public string   ClientWorkPhone             { get; set; }
        public string   ClientCellPhone             { get; set; }
        public string   Veteran                     { get; set; }
        public string   ClientRace                  { get; set; }
        public string   PrimaryLanguage             { get; set; }
        public string   Smoker                      { get; set; }
        public string   SmokingStatusAssessmentDate { get; set; }
        public string   EpisodeNumber               { get; set; }
        public string   Program                     { get; set; }
        public string   AdmissionDate               { get; set; }
        public string   AdmissionTime               { get; set; }
        public string   AttendingPractitioner       { get; set; }
        public string   TypeOfAdmission             { get; set; }
        public DateTime UTCTimestamp                { get; set; }

        /// <summary>
        /// Creates a dictionary containing all ClientAdmissionObjects.
        /// </summary>
        /// <param name = "clients"> The converted data </param>
        /// <returns> A dictionary of ClientAdmissionObjects tied to ClientIDs. </returns>
        /// <remarks>
        /// Creates ClientAdmissionObjects from the data retrieved from an external file, then puts those objects in a
        /// dictionary that ties the ClientID to the ClientAdmissionObject.
        /// </remarks>
        public static Dictionary<string, ClientAdmissionObject> CreateObjects(List<string>[] clients)
        {
            var clientAdmissionObjects = new Dictionary<string, ClientAdmissionObject>();
            //var clientCounter          = 0; // REMOVE THIS

            foreach (var client in clients)
            {
                var clientAdmissionObject = new ClientAdmissionObject
                {
                    ClientName                  = client[1] + "," + client[2],
                    ClientLastName              = client[1],
                    ClientFirstName             = client[2],
                    ClientMiddleName            = client[3],
                    Sex                         = client[4],
                    SocialSecurityNumber        = client[5],
                    EthnicOrigin                = client[6],
                    MaritalStatus               = client[7],
                    DateOfBirth                 = client[8],
                    ClientAddressStreet         = client[9],
                    ClientAddressStreet2        = client[10],
                    ClientAddressCity           = client[11],
                    ClientAddressState          = client[12],
                    ClientAddressZipcode        = client[13],
                    ClientHomePhone             = client[14],
                    ClientWorkPhone             = client[15],
                    ClientCellPhone             = client[16],
                    Veteran                     = client[17],
                    ClientRace                  = client[18],
                    PrimaryLanguage             = client[19],
                    Smoker                      = client[20],
                    SmokingStatusAssessmentDate = client[21],
                    EpisodeNumber               = client[22],
                    Program                     = client[23],
                    AdmissionDate               = client[24],
                    AttendingPractitioner       = client[25],
                    AdmissionTime               = "10:10:10",
                    TypeOfAdmission             = client[26],
                    UTCTimestamp                = new DateTime(2006, 3, 21, 2, 0, 0).ToUniversalTime()
                };

                /*  Dictionary format is { ClientID, ClientAdmissionObject }
                 */
                clientAdmissionObjects.Add(client[0], clientAdmissionObject);
            }

            return clientAdmissionObjects;
        }

        /// <summary>
        /// Check imported data for errors.
        /// </summary>
        /// <param name = "clientAdmissionObjects"> The data that will be imported </param>
        /// <returns> A list of errors. </returns>
        /// <remarks>
        /// Checks the loaded data for the following errors:
        ///     1. AdmissionDate predates the DOB
        /// </remarks>
        public static List<string> CheckForErrors(Dictionary<string, ClientAdmissionObject> clientAdmissionObjects)
        {
            /* TODO This needs to be tested.
             */
            var errorList = new List<string>();
            //var clientNumber = 0; // DELETE

            foreach (var clientAdmissionObject in clientAdmissionObjects)
            {
                if (Convert.ToDateTime(clientAdmissionObject.Value.AdmissionDate) < Convert.ToDateTime(clientAdmissionObject.Value.DateOfBirth))
                {
                    errorList.Add("ClientID: " + clientAdmissionObject.Key + " - " + clientAdmissionObject.Value.ClientName + " - Admission date < DOB");
                }
            }

            if (errorList.Count == 0)
            {
                errorList.Add("No errors found!");
            }

            return errorList;
        }

        /// <summary>
        /// Imports client demographics data into myAvatar.
        /// </summary>
        /// <param name = "clientAdmissionObjects"> Dictionary contianing the ClientAdmissionObjects </param>
        /// <param name = "systemCode">             Avatar system code [SBOX/UAT/LIVE] </param>
        /// <param name = "username">               Avatar username </param>
        /// <param name = "password">               Avatar password </param>
        /// <param name = "testMode">               Mode flag for myAvimport </param>
        /// <param name = "throttleImport">         Throttle or not </param>
        /// <remarks>
        /// Manages the data import process.
        /// </remarks>
        public static void Import(Dictionary<string, ClientAdmissionObject> clientAdmissionObjects, string systemCode, string username, string password, bool testMode, bool throttleImport)
        {
            var statusBox = new frmDuStatusBox();
            statusBox.Show();
            UpdateStatusBox(statusBox, Color.Black, Color.LightBlue, "Discharge Clients in progress...", "Starting...", false, "Done");

            var importCounter = 0;
            var totalImports  = clientAdmissionObjects.Count;

            foreach (var clientAdmissionObject in clientAdmissionObjects)
            {
                AddAdmission(systemCode, username, password, clientAdmissionObject.Value, clientAdmissionObject.Key, testMode);

                UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "Discharge Clients in progress...", "Imported record " + (importCounter + 1) + " of " + totalImports, true, "Continue");
                //UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "Discharge Clients in progress...", "Some Values " + " username = " + username + 
                  //  " password = " + password + " Key = " + clientAdmissionObject.Key.ToString() + " testMode = " + testMode + " import counter = " + (importCounter + 1) + " of " + totalImports, true, "Continue");

                importCounter++;

                /*  Throttling is enabled by default, and is recommended when importing a large number of records.
                 */
                if (throttleImport)
                {
                    DuSystem.Pause(500);
                }
            }

            UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "Discharge Clients complete!", "Click \"Continue\"", true, "Continue");

            //return "[DEFAULT] Import complete."; // DELETE
        }

        /// <summary> Adds client(s) demographic data to Avatar. </summary>
        /// <param name = "systemCode">            Avatar system code [SBOX/UAT/LIVE]        </param>
        /// <param name = "username">              Avatar username                           </param>
        /// <param name = "password">              Avatar password                           </param>
        /// <param name = "clientAdmissionObject"> The object that contains the client data. </param>
        /// <param name = "clientID">              The Client ID                             </param>
        /// <returns> The web service response. </returns>
        /// <remarks>
        /// Does the actual import into the specified Avatar environment.
        /// </remarks>
        public static string AddAdmission(string systemCode, string username, string password, ClientAdmissionObject clientAdmissionObject, string clientID, bool testMode)
        {
            switch (systemCode)
            {
                case "SBOX":
                    var SBOXSoapClient = new NTSTWEBSRV_ClientAdmission_SBOX.ClientAdmissionSoapClient();
                    var SBOXResponse   = new NTSTWEBSRV_ClientAdmission_SBOX.WebServiceResponse();
                    var SBOXSoapClient1 = new NTSTWEBSRV_ClientDischarge_SBOX.DischargeClientSoapClient();
                    var SBOXResponse1 = new NTSTWEBSRV_ClientDischarge_SBOX.WebServiceResponse();
                    //var SBOXSoapClient1 = new NTSTWEBSRV_ClientDischarge_SBOX.DischargeClientSoapClient();
                    //var SBOXResponse1 =   new NTSTWEBSRV_ClientDischarge_SBOX.WebServiceResponse();

                    if (!testMode)
                    {
                        SBOXResponse = SBOXSoapClient.AddAdmission(systemCode, username, password, clientAdmissionObject, clientID);
                        SBOXResponse1 = SBOXSoapClient1.DischargeClient(systemCode, username, password, clientAdmissionObject, clientID);
                                            }

                    return SBOXResponse.Message;

                default:
                    return "[ERROR] ClientAdmission.AddAdmission: Invalid System Code \"" + systemCode + "\"";
            }
        }

        /// <summary>
        /// Updates the statusBox
        /// </summary>
        /// <param name="statusBox">     The statusBox object </param>
        /// <param name="borderColor">   Background color (i.e. Color.Black) </param>
        /// <param name="backColor">     Background color (i.e. Color.White) </param>
        /// <param name="header">        Header text </param>
        /// <param name="status">        Status text </param>
        /// <param name="buttonEnabled"> Determines if the button is enabled [true/false] </param>
        /// <param name="buttonText">    Button text </param>
        /// <remarks>
        /// A nice, organized place to do all of the statusBox upating.
        /// </remarks>
        private static void UpdateStatusBox(frmDuStatusBox statusBox, Color borderColor, Color backColor, string header, string status, bool buttonEnabled, string buttonText)
        {
            statusBox.SetBorder(borderColor);
            statusBox.SetBackground(backColor);
            statusBox.SetHeader(header);
            statusBox.SetStatus(status);
            statusBox.ButtonEnabled(buttonEnabled);
            statusBox.ButtonText(buttonText);
            statusBox.Refresh();
        }
    }
}