﻿#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: UserManagement.cs
//   VERSION: x.y.z[-stage]
//     BUILD: 170207
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2018 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/* User Management logic.
 */
#endregion

#region USING
using myAvimport.NTSTWEBSRV_UserManagement_SBOX;
#endregion

namespace myAvimport
{
    internal class UserManagement
    {
        /// <returns> The web service response. </returns>
        public static string DoesUserExist(string sysCode, string uname, string passwd)
        {
            switch (sysCode)
            {
                case "SBOX":
                    var SBOXSoapClient = new WebServicesSoapClient();
                    var SBOXResponse   = new WebServiceResponse();

                    SBOXResponse = SBOXSoapClient.DoesUserExist("SBOX", uname, passwd, uname);

                    return SBOXResponse.Message;

                default:
                    return "ERROR";
            }
        }
    }
}