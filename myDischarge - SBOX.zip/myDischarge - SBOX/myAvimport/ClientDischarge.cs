#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: ClientDischarge.cs
//   VERSION: 0.5.0-beta
//     BUILD: 180207
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2018 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/*  Contains all of the logic for working with the WEBSVC.ClientDischarge Web Service.
 */
#endregion

#region USING
using Du;
using myAvimport.NTSTWEBSRV_ClientDischarge_SBOX;
using System;
using System.Collections.Generic;
using System.Drawing;
#endregion


namespace myAvimport
{
    public class ClientDischarge
    {
        //public string   ClientID               { get; set; }
        //public string   EpisodeNumber          { get; set; }
		public string ClientAddressStreet		 { get; set; }
		public string ClientAddressCounty		 { get; set; }
        public string ClientAddressCity          { get; set; }
        public string ClientAddressState         { get; set; }
        /// <summary>
        /// Creates a dictionary containing all ClientDischargeObjects.
        /// </summary>
        /// <param name = "clients"> The converted data </param>
        /// <returns> A dictionary of ClientDischargeObjects tied to ClientIDs. </returns>
        /// <remarks>
        /// Creates ClientDischargeObjects from the data retrieved from an external file, then puts those objects in a
        /// dictionary that ties the ClientID to the ClientDischargeObject.
        /// </remarks>
        public static Dictionary<string, ClientDischargeObject> CreateObjects(List<string>[] clients)
        {
            var clientDischargeObjects = new Dictionary<string, ClientDischargeObject>();
            //var clientCounter          = 0; // REMOVE THIS

            foreach (var client in clients)
            {
                var clientDischargeObject = new ClientDischargeObject
                {
                    //ClientID            = client[0],
                    //EpisodeNumber       = client[1],
					ClientAddressStreet = client[2],
					ClientAddressCounty = client[3],
					ClientAddressCity   = client[4],
					ClientAddressState  = client[5],
                    DateOfDischarge = "2019-01-14",
                    UTCTimestamp    = new DateTime(2006, 3, 21, 2, 0, 0).ToUniversalTime()
                };

                /*  Dictionary format is { ClientID, ClientDischargeObject }
                 */
                clientDischargeObjects.Add(client[0], clientDischargeObject);
            }

            return clientDischargeObjects;
        }

        /// <summary>
        /// Check imported data for errors.
        /// </summary>
        /// <param name = "clientDischargeObjects"> The data that will be imported </param>
        /// <returns> A list of errors. </returns>
        /// <remarks>
        /// Checks the loaded data for the following errors:
        ///     1. DischargeDate predates the DOB
        /// </remarks>
        public static List<string> CheckForErrors(Dictionary<string, ClientDischargeObject> clientDischargeObjects)
        {
            /* TODO This needs to be tested.
             */
            var errorList = new List<string>();
            //var clientNumber = 0; // DELETE

            foreach (var clientDischargeObject in clientDischargeObjects)
            {
                if (Convert.ToDateTime(clientDischargeObject.Value.DateOfDischarge) < Convert.ToDateTime(clientDischargeObject.Value.DateOfDischarge))
                {
                    errorList.Add("ClientID: " + clientDischargeObject.Key + " - " + " - Discharge date < DOB");
                }
            }

            if (errorList.Count == 0)
            {
                errorList.Add("No errors found!");
            }

            return errorList;
        }

        /// <summary>
        /// Imports client demographics data into myAvatar.
        /// </summary>
        /// <param name = "clientDischargeObjects"> Dictionary contianing the ClientDischargeObjects </param>
        /// <param name = "systemCode">             Avatar system code [SBOX] </param>
        /// <param name = "username">               Avatar username </param>
        /// <param name = "password">               Avatar password </param>
        /// <param name = "testMode">               Mode flag for myAvImport </param>
        /// <param name = "throttleImport">         Throttle or not </param>
        /// <remarks>
        /// Manages the data import process.
        /// </remarks>
        public static void Discharge(Dictionary<string, ClientDischargeObject> clientDischargeObjects, string systemCode, string username, string password, bool testMode, bool throttleImport)
        {
            var statusBox = new frmDuStatusBox();
            statusBox.Show();
            var dischargeCounter = 0;
            var totalDischarges  = clientDischargeObjects.Count;

            foreach (var clientDischargeObject in clientDischargeObjects)
            {
                DischargeClient(systemCode, username, password, clientDischargeObject.Value, clientDischargeObject.Key, testMode);
                UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "Discharge Clients in progress...", "Discharged Client " + (dischargeCounter + 1) + " of " + totalDischarges, true, "Continue");
                dischargeCounter++;
                /*  Throttling is enabled by default, and is recommended when importing a large number of records.
                */
                if (throttleImport)
                {
                    DuSystem.Pause(500);
                }
            }

            UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "Discharge Clients complete!", "Click \"Continue\"", true, "Continue");

            //return "[DEFAULT] Discharge complete."; // DELETE
        }

        /// <summary> Adds client(s) demographic data to Avatar. </summary>
        /// <param name = "systemCode">            Avatar system code [SBOX]        </param>
        /// <param name = "username">              Avatar username                           </param>
        /// <param name = "password">              Avatar password                           </param>
        /// <param name = "clientDischargeObject"> The object that contains the client data. </param>
        /// <param name = "clientID">              The Client ID                             </param>
        /// <returns> The web service response. </returns>
        /// <remarks>
        /// Does the actual import into the specified Avatar environment.
        /// </remarks>
        public static string DischargeClient(string systemCode, string username, string password, ClientDischargeObject clientDischargeObject, string clientID, bool testMode)
        {
            //var statusBox = new frmDuStatusBox();
            //statusBox.Show();

            switch (systemCode)
            {
                case "SBOX":
                    var SBOXSoapClient = new NTSTWEBSRV_ClientDischarge_SBOX.ClientDischargeSoapClient();
                    var SBOXResponse   = new NTSTWEBSRV_ClientDischarge_SBOX.WebServiceResponse();
                     if (!testMode) {

                        //UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "password: ", password, true, "Continue");
                        //UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "username: ", username, true, "Continue");
                        //UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "systemCode: ", systemCode, true, "Continue");
                        //UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "1. Discharge Client ID: ", clientID, true, "Continue");
                        SBOXResponse = SBOXSoapClient.DischargeClient(systemCode, username, password, clientDischargeObject, clientID, "1");

                    }

                    return SBOXResponse.Message;

                default:
                    return "[ERROR] ClientDischarge.DischargeClient: Invalid System Code \"" + systemCode + "\"";
            }
        }

        /// <summary>
        /// Updates the statusBox
        /// </summary>
        /// <param name="statusBox">     The statusBox object </param>
        /// <param name="borderColor">   Background color (i.e. Color.Black) </param>
        /// <param name="backColor">     Background color (i.e. Color.White) </param>
        /// <param name="header">        Header text </param>
        /// <param name="status">        Status text </param>
        /// <param name="buttonEnabled"> Determines if the button is enabled [true/false] </param>
        /// <param name="buttonText">    Button text </param>
        /// <remarks>
        /// A nice, organized place to do all of the statusBox upating.
        /// </remarks>
        private static void UpdateStatusBox(frmDuStatusBox statusBox, Color borderColor, Color backColor, string header, string status, bool buttonEnabled, string buttonText)
        {
            statusBox.SetBorder(borderColor);
            //statusBox.SetBackground(backColor);
            statusBox.SetBackground(Color.LightBlue);
            statusBox.SetHeader(header);
            statusBox.SetStatus(status);
            statusBox.ButtonEnabled(buttonEnabled);
            statusBox.ButtonText(buttonText);
            statusBox.Refresh();
        }
    }
}