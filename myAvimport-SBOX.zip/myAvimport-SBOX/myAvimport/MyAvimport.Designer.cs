﻿namespace myAvimport
{
    partial class MyAvimport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlDataImport = new System.Windows.Forms.Panel();
            this.pnlLogin = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.tbxUsername = new System.Windows.Forms.TextBox();
            this.pnlLoggedIn = new System.Windows.Forms.Panel();
            this.lblLoggedInStatus = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbxPreview = new System.Windows.Forms.TextBox();
            this.cbxThrottleImport = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cbxTestMode = new System.Windows.Forms.CheckBox();
            this.btnCancelImport = new System.Windows.Forms.Button();
            this.lblIndicatorResolve = new System.Windows.Forms.Label();
            this.lblResolve = new System.Windows.Forms.Label();
            this.lblIndicatorErrors = new System.Windows.Forms.Label();
            this.lblIndicatorPreview = new System.Windows.Forms.Label();
            this.lblImport = new System.Windows.Forms.Label();
            this.lblIndicatorImport = new System.Windows.Forms.Label();
            this.lblIndicatorLoadData = new System.Windows.Forms.Label();
            this.lblIndicatorCredentials = new System.Windows.Forms.Label();
            this.lblIndicatorChooseEnvironment = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rdoSBOX = new System.Windows.Forms.RadioButton();
            this.pnlHeaderMyAvimport = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblDataImportHeader = new System.Windows.Forms.Label();
            this.lblChooseEnvironment = new System.Windows.Forms.Label();
            this.lblLoadData = new System.Windows.Forms.Label();
            this.lblCredentials = new System.Windows.Forms.Label();
            this.btnImport = new System.Windows.Forms.Button();
            this.btnLoadClientDemographicsData = new System.Windows.Forms.Button();
            this.lblDescriptionDataPreview = new System.Windows.Forms.Label();
            this.lblPreview = new System.Windows.Forms.Label();
            this.btnPreviousRecord = new System.Windows.Forms.Button();
            this.lblClientRecordDisplay = new System.Windows.Forms.Label();
            this.btnNextRecord = new System.Windows.Forms.Button();
            this.lblErrors = new System.Windows.Forms.Label();
            this.tbxErrors = new System.Windows.Forms.TextBox();
            this.btnAcceptErrors = new System.Windows.Forms.Button();
            this.ofdFileToConvert = new System.Windows.Forms.OpenFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlDataImport.SuspendLayout();
            this.pnlLogin.SuspendLayout();
            this.pnlLoggedIn.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlHeaderMyAvimport.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlDataImport
            // 
            this.pnlDataImport.BackColor = System.Drawing.Color.White;
            this.pnlDataImport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDataImport.Controls.Add(this.pnlHeaderMyAvimport);
            this.pnlDataImport.Controls.Add(this.pnlLogin);
            this.pnlDataImport.Controls.Add(this.pnlLoggedIn);
            this.pnlDataImport.Controls.Add(this.panel1);
            this.pnlDataImport.Controls.Add(this.cbxThrottleImport);
            this.pnlDataImport.Controls.Add(this.label15);
            this.pnlDataImport.Controls.Add(this.cbxTestMode);
            this.pnlDataImport.Controls.Add(this.btnCancelImport);
            this.pnlDataImport.Controls.Add(this.lblIndicatorResolve);
            this.pnlDataImport.Controls.Add(this.lblResolve);
            this.pnlDataImport.Controls.Add(this.lblIndicatorErrors);
            this.pnlDataImport.Controls.Add(this.lblIndicatorPreview);
            this.pnlDataImport.Controls.Add(this.lblImport);
            this.pnlDataImport.Controls.Add(this.lblIndicatorImport);
            this.pnlDataImport.Controls.Add(this.lblIndicatorLoadData);
            this.pnlDataImport.Controls.Add(this.lblIndicatorCredentials);
            this.pnlDataImport.Controls.Add(this.lblIndicatorChooseEnvironment);
            this.pnlDataImport.Controls.Add(this.panel2);
            this.pnlDataImport.Controls.Add(this.lblChooseEnvironment);
            this.pnlDataImport.Controls.Add(this.lblLoadData);
            this.pnlDataImport.Controls.Add(this.lblCredentials);
            this.pnlDataImport.Controls.Add(this.btnImport);
            this.pnlDataImport.Controls.Add(this.btnLoadClientDemographicsData);
            this.pnlDataImport.Controls.Add(this.lblDescriptionDataPreview);
            this.pnlDataImport.Controls.Add(this.lblPreview);
            this.pnlDataImport.Controls.Add(this.btnPreviousRecord);
            this.pnlDataImport.Controls.Add(this.lblClientRecordDisplay);
            this.pnlDataImport.Controls.Add(this.btnNextRecord);
            this.pnlDataImport.Controls.Add(this.lblErrors);
            this.pnlDataImport.Controls.Add(this.tbxErrors);
            this.pnlDataImport.Controls.Add(this.btnAcceptErrors);
            this.pnlDataImport.ForeColor = System.Drawing.Color.Black;
            this.pnlDataImport.Location = new System.Drawing.Point(5, 5);
            this.pnlDataImport.Name = "pnlDataImport";
            this.pnlDataImport.Size = new System.Drawing.Size(1174, 652);
            this.pnlDataImport.TabIndex = 40;
            // 
            // pnlLogin
            // 
            this.pnlLogin.Controls.Add(this.label1);
            this.pnlLogin.Controls.Add(this.label3);
            this.pnlLogin.Controls.Add(this.btnLogin);
            this.pnlLogin.Controls.Add(this.tbxPassword);
            this.pnlLogin.Controls.Add(this.tbxUsername);
            this.pnlLogin.Location = new System.Drawing.Point(20, 217);
            this.pnlLogin.Name = "pnlLogin";
            this.pnlLogin.Size = new System.Drawing.Size(275, 89);
            this.pnlLogin.TabIndex = 100;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 16);
            this.label1.TabIndex = 67;
            this.label1.Text = "Username";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 16);
            this.label3.TabIndex = 68;
            this.label3.Text = "Password";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnLogin.BackgroundImage = global::myAvimport.Properties.Resources.icons8_login_32_grey;
            this.btnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogin.Enabled = false;
            this.btnLogin.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLogin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogin.Location = new System.Drawing.Point(223, 63);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(22, 22);
            this.btnLogin.TabIndex = 71;
            this.btnLogin.TabStop = false;
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // tbxPassword
            // 
            this.tbxPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbxPassword.Enabled = false;
            this.tbxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPassword.Location = new System.Drawing.Point(33, 63);
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(184, 22);
            this.tbxPassword.TabIndex = 65;
            this.tbxPassword.UseSystemPasswordChar = true;
            this.tbxPassword.TextChanged += new System.EventHandler(this.TbxPassword_TextChanged);
            // 
            // tbxUsername
            // 
            this.tbxUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbxUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbxUsername.Enabled = false;
            this.tbxUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxUsername.ForeColor = System.Drawing.Color.Black;
            this.tbxUsername.Location = new System.Drawing.Point(33, 21);
            this.tbxUsername.Name = "tbxUsername";
            this.tbxUsername.Size = new System.Drawing.Size(184, 22);
            this.tbxUsername.TabIndex = 64;
            this.tbxUsername.TextChanged += new System.EventHandler(this.TbxUsername_TextChanged);
            // 
            // pnlLoggedIn
            // 
            this.pnlLoggedIn.Controls.Add(this.lblLoggedInStatus);
            this.pnlLoggedIn.Location = new System.Drawing.Point(20, 217);
            this.pnlLoggedIn.Name = "pnlLoggedIn";
            this.pnlLoggedIn.Size = new System.Drawing.Size(275, 89);
            this.pnlLoggedIn.TabIndex = 101;
            // 
            // lblLoggedInStatus
            // 
            this.lblLoggedInStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoggedInStatus.Location = new System.Drawing.Point(3, 34);
            this.lblLoggedInStatus.Name = "lblLoggedInStatus";
            this.lblLoggedInStatus.Size = new System.Drawing.Size(269, 23);
            this.lblLoggedInStatus.TabIndex = 0;
            this.lblLoggedInStatus.Text = "You are logged into SBOX as USERNAME";
            this.lblLoggedInStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.tbxPreview);
            this.panel1.Location = new System.Drawing.Point(549, 54);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(307, 576);
            this.panel1.TabIndex = 99;
            // 
            // tbxPreview
            // 
            this.tbxPreview.BackColor = System.Drawing.Color.White;
            this.tbxPreview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxPreview.Enabled = false;
            this.tbxPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPreview.ForeColor = System.Drawing.Color.Black;
            this.tbxPreview.Location = new System.Drawing.Point(6, 1);
            this.tbxPreview.Multiline = true;
            this.tbxPreview.Name = "tbxPreview";
            this.tbxPreview.Size = new System.Drawing.Size(298, 572);
            this.tbxPreview.TabIndex = 20;
            // 
            // cbxThrottleImport
            // 
            this.cbxThrottleImport.AutoSize = true;
            this.cbxThrottleImport.Checked = true;
            this.cbxThrottleImport.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxThrottleImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbxThrottleImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxThrottleImport.Location = new System.Drawing.Point(26, 608);
            this.cbxThrottleImport.Name = "cbxThrottleImport";
            this.cbxThrottleImport.Size = new System.Drawing.Size(109, 20);
            this.cbxThrottleImport.TabIndex = 98;
            this.cbxThrottleImport.Text = "Throttle import";
            this.cbxThrottleImport.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.SteelBlue;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(20, 555);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(275, 25);
            this.label15.TabIndex = 97;
            this.label15.Text = "Other settings";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbxTestMode
            // 
            this.cbxTestMode.AutoSize = true;
            this.cbxTestMode.Checked = true;
            this.cbxTestMode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxTestMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbxTestMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTestMode.Location = new System.Drawing.Point(26, 583);
            this.cbxTestMode.Name = "cbxTestMode";
            this.cbxTestMode.Size = new System.Drawing.Size(89, 20);
            this.cbxTestMode.TabIndex = 96;
            this.cbxTestMode.Text = "Test Mode";
            this.cbxTestMode.UseVisualStyleBackColor = true;
            this.cbxTestMode.CheckedChanged += new System.EventHandler(this.CbxTestMode_CheckedChanged);
            // 
            // btnCancelImport
            // 
            this.btnCancelImport.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnCancelImport.Enabled = false;
            this.btnCancelImport.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnCancelImport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnCancelImport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnCancelImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelImport.ForeColor = System.Drawing.Color.Black;
            this.btnCancelImport.Location = new System.Drawing.Point(910, 512);
            this.btnCancelImport.Name = "btnCancelImport";
            this.btnCancelImport.Size = new System.Drawing.Size(241, 35);
            this.btnCancelImport.TabIndex = 95;
            this.btnCancelImport.TabStop = false;
            this.btnCancelImport.Text = "Cancel data import";
            this.btnCancelImport.UseVisualStyleBackColor = false;
            this.btnCancelImport.Click += new System.EventHandler(this.BtnCancelImport_Click);
            // 
            // lblIndicatorResolve
            // 
            this.lblIndicatorResolve.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorResolve.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorResolve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorResolve.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorResolve.Location = new System.Drawing.Point(876, 434);
            this.lblIndicatorResolve.Name = "lblIndicatorResolve";
            this.lblIndicatorResolve.Size = new System.Drawing.Size(35, 35);
            this.lblIndicatorResolve.TabIndex = 93;
            this.lblIndicatorResolve.Text = "6";
            this.lblIndicatorResolve.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblResolve
            // 
            this.lblResolve.BackColor = System.Drawing.Color.SteelBlue;
            this.lblResolve.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResolve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResolve.ForeColor = System.Drawing.Color.White;
            this.lblResolve.Location = new System.Drawing.Point(910, 434);
            this.lblResolve.Name = "lblResolve";
            this.lblResolve.Size = new System.Drawing.Size(241, 35);
            this.lblResolve.TabIndex = 92;
            this.lblResolve.Text = "Resolve errors";
            this.lblResolve.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorErrors
            // 
            this.lblIndicatorErrors.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorErrors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorErrors.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorErrors.Location = new System.Drawing.Point(876, 20);
            this.lblIndicatorErrors.Name = "lblIndicatorErrors";
            this.lblIndicatorErrors.Size = new System.Drawing.Size(35, 35);
            this.lblIndicatorErrors.TabIndex = 89;
            this.lblIndicatorErrors.Text = "5";
            this.lblIndicatorErrors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorPreview
            // 
            this.lblIndicatorPreview.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorPreview.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorPreview.Location = new System.Drawing.Point(316, 20);
            this.lblIndicatorPreview.Name = "lblIndicatorPreview";
            this.lblIndicatorPreview.Size = new System.Drawing.Size(35, 35);
            this.lblIndicatorPreview.TabIndex = 88;
            this.lblIndicatorPreview.Text = "4";
            this.lblIndicatorPreview.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblImport
            // 
            this.lblImport.BackColor = System.Drawing.Color.SteelBlue;
            this.lblImport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImport.ForeColor = System.Drawing.Color.White;
            this.lblImport.Location = new System.Drawing.Point(910, 555);
            this.lblImport.Name = "lblImport";
            this.lblImport.Size = new System.Drawing.Size(241, 35);
            this.lblImport.TabIndex = 85;
            this.lblImport.Text = "Discharge Clients from myAvatar";
            this.lblImport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorImport
            // 
            this.lblIndicatorImport.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorImport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorImport.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorImport.Location = new System.Drawing.Point(876, 555);
            this.lblIndicatorImport.Name = "lblIndicatorImport";
            this.lblIndicatorImport.Size = new System.Drawing.Size(35, 35);
            this.lblIndicatorImport.TabIndex = 84;
            this.lblIndicatorImport.Text = "7";
            this.lblIndicatorImport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorLoadData
            // 
            this.lblIndicatorLoadData.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorLoadData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorLoadData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorLoadData.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorLoadData.Location = new System.Drawing.Point(20, 309);
            this.lblIndicatorLoadData.Name = "lblIndicatorLoadData";
            this.lblIndicatorLoadData.Size = new System.Drawing.Size(35, 35);
            this.lblIndicatorLoadData.TabIndex = 83;
            this.lblIndicatorLoadData.Text = "3";
            this.lblIndicatorLoadData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorCredentials
            // 
            this.lblIndicatorCredentials.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorCredentials.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorCredentials.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorCredentials.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorCredentials.Location = new System.Drawing.Point(20, 179);
            this.lblIndicatorCredentials.Name = "lblIndicatorCredentials";
            this.lblIndicatorCredentials.Size = new System.Drawing.Size(35, 35);
            this.lblIndicatorCredentials.TabIndex = 82;
            this.lblIndicatorCredentials.Text = "2";
            this.lblIndicatorCredentials.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorChooseEnvironment
            // 
            this.lblIndicatorChooseEnvironment.BackColor = System.Drawing.Color.LightGreen;
            this.lblIndicatorChooseEnvironment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorChooseEnvironment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorChooseEnvironment.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorChooseEnvironment.Location = new System.Drawing.Point(20, 98);
            this.lblIndicatorChooseEnvironment.Name = "lblIndicatorChooseEnvironment";
            this.lblIndicatorChooseEnvironment.Size = new System.Drawing.Size(35, 35);
            this.lblIndicatorChooseEnvironment.TabIndex = 81;
            this.lblIndicatorChooseEnvironment.Text = "1";
            this.lblIndicatorChooseEnvironment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rdoSBOX);
            this.panel2.Location = new System.Drawing.Point(54, 138);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(241, 33);
            this.panel2.TabIndex = 80;
            // 
            // rdoSBOX
            // 
            this.rdoSBOX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rdoSBOX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoSBOX.Location = new System.Drawing.Point(12, 4);
            this.rdoSBOX.Name = "rdoSBOX";
            this.rdoSBOX.Size = new System.Drawing.Size(65, 25);
            this.rdoSBOX.TabIndex = 0;
            this.rdoSBOX.Text = "SBOX";
            this.rdoSBOX.UseVisualStyleBackColor = true;
            this.rdoSBOX.CheckedChanged += new System.EventHandler(this.RdoSBOX_CheckedChanged);
            // 
            // pnlHeaderMyAvimport
            // 
            this.pnlHeaderMyAvimport.BackColor = System.Drawing.Color.Wheat;
            this.pnlHeaderMyAvimport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlHeaderMyAvimport.Controls.Add(this.label2);
            this.pnlHeaderMyAvimport.Controls.Add(this.label4);
            this.pnlHeaderMyAvimport.Controls.Add(this.lblDataImportHeader);
            this.pnlHeaderMyAvimport.Location = new System.Drawing.Point(20, 20);
            this.pnlHeaderMyAvimport.Name = "pnlHeaderMyAvimport";
            this.pnlHeaderMyAvimport.Size = new System.Drawing.Size(275, 151);
            this.pnlHeaderMyAvimport.TabIndex = 78;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Wheat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Orange;
            this.label4.Location = new System.Drawing.Point(25, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 17);
            this.label4.TabIndex = 79;
            this.label4.Text = "myDISCHARGE";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDataImportHeader
            // 
            this.lblDataImportHeader.BackColor = System.Drawing.Color.Wheat;
            this.lblDataImportHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataImportHeader.ForeColor = System.Drawing.Color.Orange;
            this.lblDataImportHeader.Location = new System.Drawing.Point(11, 25);
            this.lblDataImportHeader.Name = "lblDataImportHeader";
            this.lblDataImportHeader.Size = new System.Drawing.Size(250, 37);
            this.lblDataImportHeader.TabIndex = 44;
            this.lblDataImportHeader.Text = "myDischarge";
            this.lblDataImportHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblChooseEnvironment
            // 
            this.lblChooseEnvironment.BackColor = System.Drawing.Color.SteelBlue;
            this.lblChooseEnvironment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblChooseEnvironment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChooseEnvironment.ForeColor = System.Drawing.Color.White;
            this.lblChooseEnvironment.Location = new System.Drawing.Point(54, 98);
            this.lblChooseEnvironment.Name = "lblChooseEnvironment";
            this.lblChooseEnvironment.Size = new System.Drawing.Size(241, 35);
            this.lblChooseEnvironment.TabIndex = 72;
            this.lblChooseEnvironment.Text = "Choose an Avatar environment";
            this.lblChooseEnvironment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLoadData
            // 
            this.lblLoadData.BackColor = System.Drawing.Color.SteelBlue;
            this.lblLoadData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLoadData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoadData.ForeColor = System.Drawing.Color.White;
            this.lblLoadData.Location = new System.Drawing.Point(54, 309);
            this.lblLoadData.Name = "lblLoadData";
            this.lblLoadData.Size = new System.Drawing.Size(241, 35);
            this.lblLoadData.TabIndex = 70;
            this.lblLoadData.Text = "Load clients to discharge";
            this.lblLoadData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCredentials
            // 
            this.lblCredentials.BackColor = System.Drawing.Color.SteelBlue;
            this.lblCredentials.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCredentials.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCredentials.ForeColor = System.Drawing.Color.White;
            this.lblCredentials.Location = new System.Drawing.Point(54, 179);
            this.lblCredentials.Name = "lblCredentials";
            this.lblCredentials.Size = new System.Drawing.Size(241, 35);
            this.lblCredentials.TabIndex = 63;
            this.lblCredentials.Text = "Enter your myAvatar Credentials";
            this.lblCredentials.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnImport
            // 
            this.btnImport.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnImport.Enabled = false;
            this.btnImport.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnImport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnImport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImport.ForeColor = System.Drawing.Color.Black;
            this.btnImport.Location = new System.Drawing.Point(910, 595);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(241, 35);
            this.btnImport.TabIndex = 62;
            this.btnImport.TabStop = false;
            this.btnImport.Text = "Discharge Clients";
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.Click += new System.EventHandler(this.BtnImport_Click);
            // 
            // btnLoadClientDemographicsData
            // 
            this.btnLoadClientDemographicsData.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnLoadClientDemographicsData.Enabled = false;
            this.btnLoadClientDemographicsData.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnLoadClientDemographicsData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnLoadClientDemographicsData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnLoadClientDemographicsData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadClientDemographicsData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadClientDemographicsData.ForeColor = System.Drawing.Color.Black;
            this.btnLoadClientDemographicsData.Location = new System.Drawing.Point(54, 349);
            this.btnLoadClientDemographicsData.Name = "btnLoadClientDemographicsData";
            this.btnLoadClientDemographicsData.Size = new System.Drawing.Size(241, 35);
            this.btnLoadClientDemographicsData.TabIndex = 59;
            this.btnLoadClientDemographicsData.TabStop = false;
            this.btnLoadClientDemographicsData.Text = "Client Demographics";
            this.btnLoadClientDemographicsData.UseVisualStyleBackColor = false;
            this.btnLoadClientDemographicsData.Click += new System.EventHandler(this.BtnLoadClientDemographicsData_Click);
            // 
            // lblDescriptionDataPreview
            // 
            this.lblDescriptionDataPreview.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblDescriptionDataPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDescriptionDataPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriptionDataPreview.ForeColor = System.Drawing.Color.Black;
            this.lblDescriptionDataPreview.Location = new System.Drawing.Point(316, 54);
            this.lblDescriptionDataPreview.Name = "lblDescriptionDataPreview";
            this.lblDescriptionDataPreview.Size = new System.Drawing.Size(234, 576);
            this.lblDescriptionDataPreview.TabIndex = 45;
            this.lblDescriptionDataPreview.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblPreview
            // 
            this.lblPreview.BackColor = System.Drawing.Color.SteelBlue;
            this.lblPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreview.ForeColor = System.Drawing.Color.White;
            this.lblPreview.Location = new System.Drawing.Point(350, 20);
            this.lblPreview.Name = "lblPreview";
            this.lblPreview.Size = new System.Drawing.Size(200, 35);
            this.lblPreview.TabIndex = 49;
            this.lblPreview.Text = "Preview data";
            this.lblPreview.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPreviousRecord
            // 
            this.btnPreviousRecord.BackColor = System.Drawing.Color.White;
            this.btnPreviousRecord.BackgroundImage = global::myAvimport.Properties.Resources.icons8_back_32;
            this.btnPreviousRecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPreviousRecord.FlatAppearance.BorderSize = 0;
            this.btnPreviousRecord.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnPreviousRecord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnPreviousRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPreviousRecord.Font = new System.Drawing.Font("Coda", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousRecord.ForeColor = System.Drawing.Color.Black;
            this.btnPreviousRecord.Location = new System.Drawing.Point(610, 24);
            this.btnPreviousRecord.Name = "btnPreviousRecord";
            this.btnPreviousRecord.Size = new System.Drawing.Size(24, 24);
            this.btnPreviousRecord.TabIndex = 21;
            this.btnPreviousRecord.UseVisualStyleBackColor = false;
            this.btnPreviousRecord.Click += new System.EventHandler(this.BtnPreviousRecord_Click);
            // 
            // lblClientRecordDisplay
            // 
            this.lblClientRecordDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientRecordDisplay.ForeColor = System.Drawing.Color.Black;
            this.lblClientRecordDisplay.Location = new System.Drawing.Point(637, 25);
            this.lblClientRecordDisplay.Name = "lblClientRecordDisplay";
            this.lblClientRecordDisplay.Size = new System.Drawing.Size(132, 23);
            this.lblClientRecordDisplay.TabIndex = 43;
            this.lblClientRecordDisplay.Text = "Record 1 of ???";
            this.lblClientRecordDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNextRecord
            // 
            this.btnNextRecord.BackColor = System.Drawing.Color.White;
            this.btnNextRecord.BackgroundImage = global::myAvimport.Properties.Resources.icons8_forward_32;
            this.btnNextRecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNextRecord.FlatAppearance.BorderSize = 0;
            this.btnNextRecord.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNextRecord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNextRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNextRecord.Font = new System.Drawing.Font("Coda", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextRecord.ForeColor = System.Drawing.Color.Black;
            this.btnNextRecord.Location = new System.Drawing.Point(772, 25);
            this.btnNextRecord.Name = "btnNextRecord";
            this.btnNextRecord.Size = new System.Drawing.Size(24, 24);
            this.btnNextRecord.TabIndex = 37;
            this.btnNextRecord.UseVisualStyleBackColor = false;
            this.btnNextRecord.Click += new System.EventHandler(this.BtnNextRecord_Click);
            // 
            // lblErrors
            // 
            this.lblErrors.BackColor = System.Drawing.Color.SteelBlue;
            this.lblErrors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrors.ForeColor = System.Drawing.Color.White;
            this.lblErrors.Location = new System.Drawing.Point(910, 20);
            this.lblErrors.Name = "lblErrors";
            this.lblErrors.Size = new System.Drawing.Size(241, 35);
            this.lblErrors.TabIndex = 51;
            this.lblErrors.Text = "Review errors";
            this.lblErrors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxErrors
            // 
            this.tbxErrors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbxErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxErrors.Location = new System.Drawing.Point(876, 54);
            this.tbxErrors.Multiline = true;
            this.tbxErrors.Name = "tbxErrors";
            this.tbxErrors.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbxErrors.Size = new System.Drawing.Size(275, 377);
            this.tbxErrors.TabIndex = 46;
            // 
            // btnAcceptErrors
            // 
            this.btnAcceptErrors.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnAcceptErrors.Enabled = false;
            this.btnAcceptErrors.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAcceptErrors.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnAcceptErrors.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnAcceptErrors.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAcceptErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAcceptErrors.ForeColor = System.Drawing.Color.Black;
            this.btnAcceptErrors.Location = new System.Drawing.Point(910, 474);
            this.btnAcceptErrors.Name = "btnAcceptErrors";
            this.btnAcceptErrors.Size = new System.Drawing.Size(241, 35);
            this.btnAcceptErrors.TabIndex = 47;
            this.btnAcceptErrors.TabStop = false;
            this.btnAcceptErrors.Text = "Accept errors";
            this.btnAcceptErrors.UseVisualStyleBackColor = false;
            this.btnAcceptErrors.Click += new System.EventHandler(this.BtnAcceptErrors_Click);
            // 
            // ofdFileToConvert
            // 
            this.ofdFileToConvert.FileName = "openFileDialog1";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Wheat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkOrange;
            this.label2.Location = new System.Drawing.Point(11, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 74);
            this.label2.TabIndex = 80;
            this.label2.Text = "SBOX";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MyAvimport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 662);
            this.Controls.Add(this.pnlDataImport);
            this.Name = "MyAvimport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "myAvimport - SBOX";
            this.pnlDataImport.ResumeLayout(false);
            this.pnlDataImport.PerformLayout();
            this.pnlLogin.ResumeLayout(false);
            this.pnlLogin.PerformLayout();
            this.pnlLoggedIn.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.pnlHeaderMyAvimport.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlDataImport;
        private System.Windows.Forms.Label lblDataImportHeader;
        private System.Windows.Forms.Label lblDescriptionDataPreview;
        private System.Windows.Forms.Label lblPreview;
        private System.Windows.Forms.TextBox tbxPreview;
        private System.Windows.Forms.Button btnPreviousRecord;
        private System.Windows.Forms.Label lblClientRecordDisplay;
        private System.Windows.Forms.Button btnNextRecord;
        private System.Windows.Forms.Label lblErrors;
        private System.Windows.Forms.TextBox tbxErrors;
        private System.Windows.Forms.Button btnAcceptErrors;
        private System.Windows.Forms.OpenFileDialog ofdFileToConvert;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.Label lblLoadData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.TextBox tbxUsername;
        private System.Windows.Forms.Label lblCredentials;
        private System.Windows.Forms.Button btnLoadClientDemographicsData;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblChooseEnvironment;
        private System.Windows.Forms.Panel pnlHeaderMyAvimport;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblImport;
        private System.Windows.Forms.Label lblIndicatorImport;
        private System.Windows.Forms.Label lblIndicatorLoadData;
        private System.Windows.Forms.Label lblIndicatorCredentials;
        private System.Windows.Forms.Label lblIndicatorChooseEnvironment;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdoSBOX;
        private System.Windows.Forms.Button btnCancelImport;
        private System.Windows.Forms.Label lblIndicatorResolve;
        private System.Windows.Forms.Label lblResolve;
        private System.Windows.Forms.Label lblIndicatorErrors;
        private System.Windows.Forms.Label lblIndicatorPreview;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox cbxTestMode;
        private System.Windows.Forms.CheckBox cbxThrottleImport;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlLogin;
        private System.Windows.Forms.Panel pnlLoggedIn;
        private System.Windows.Forms.Label lblLoggedInStatus;
        private System.Windows.Forms.Label label2;
    }
}

