﻿#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: CrossEpisodeFinancialEligibility.cs
//   VERSION: 0.5.0-beta
//     BUILD: 180207
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2018 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/*  Contains all of the logic for working with the WEBSVC.CrossEpisodeFinancialEligibility Web Service.
 */
#endregion

#region USING
using Du;
using myAvimport.NTSTWEBSRV_CrossEpisodeFinancialEligibility_SBOX;
using System;
using System.Collections.Generic;
using System.Drawing;
#endregion

namespace myAvimport
{
    public class CrossEpisodeFinancialEligibility
    {
        //public string   PatientID                  { get; set; } // TODO - needed?
        public string   GuarantorNumber            { get; set; }
        public string   GuarantorName              { get; set; }
        public string   CoverageEffectiveDate      { get; set; }
        public string   ClientsRelationship        { get; set; }
        public string   SubscriberPolicyNumber     { get; set; }
        public string   SubscriberName             { get; set; }
        public string   SubscriberAddress1         { get; set; }
        public string   SubscriberAddress2         { get; set; }
        public string   SubscriberCity             { get; set; }
        public string   SubscriberState            { get; set; }
        public string   SubscriberZip              { get; set; }
        public string   SubscribersSex             { get; set; }
        public string   SubscribersSSNumber        { get; set; }
        public string   SubscriberEmployerName     { get; set; }
        public string   SubscribersBirthDate       { get; set; }
        public string   SubscriberMedicaidNumber   { get; set; }
        public string   EligibilityVerified        { get; set; }
        public string   GuarantorPlan              { get; set; }
        public string   SubscriberAssignOfBenefits { get; set; }
        public string   CoordinationOfBenefits     { get; set; }
        public string   SubscribersCoveredDays     { get; set; }
        public string   MaximumCoveredDollars      { get; set; }
        public string   SubscriberReleaseOfInfo    { get; set; }
        public string   CustomizeGuarantorPlan     { get; set; }
        public string   GuarantorOrderNumber       { get; set; }
        public DateTime UTCTimestamp { get; set; }

        /// <summary>
        /// Create the ArrayOfGuarantorSelectionObjectGuarantorSelectionObject objects.
        /// </summary>
        /// <param name="importedData"> The imported data array </param>
        /// <returns> A dictionary of ArrayOfGuarantorSelectionObjectGuarantorSelectionObjects tied to ClientIDs. </returns>
        /// <remarks>
        /// Creates ArrayOfGuarantorSelectionObjectGuarantorSelectionObject from the data retrieved from an external
        /// file, then puts those objects in a dictionary that ties the ClientID to the ArrayOfGuarantorSelectionObjectGuarantorSelectionObjects.
        /// </remarks>
        public static Dictionary<string, ArrayOfGuarantorSelectionObjectGuarantorSelectionObject> CreateObjects(List<string>[] importedData)
        {
            var arrayOfGuarantorSelectionObjectGuarantorSelectionObjects = new Dictionary<string, ArrayOfGuarantorSelectionObjectGuarantorSelectionObject>();
            //var clientCounter = 0; // REMOVE THIS

            //var listOfArrayOfGuarantorSelectionObjectGuarantorSelectionObject = new ArrayOfGuarantorSelectionObjectGuarantorSelectionObject();


            foreach (var client in importedData)
            {
                /*  Note that "SubscriberEmployerName" and "SubscriberMedicaidNumber" are both set to " ". This may not
                 *  always be the case.
                 */
                var guarantorSelectionObject = new GuarantorSelectionObject
                {
                    GuarantorNumber            = client[1],
                    GuarantorName              = client[2],
                    CoverageEffectiveDate      = client[3],
                    ClientsRelationship        = client[4],
                    SubscriberPolicyNumber     = client[5],
                    SubscribersName            = client[6],
                    SubscriberAddress1         = client[7],
                    SubscriberAddress2         = client[8],
                    SubscriberCity             = client[9],
                    SubscriberState            = client[10],
                    SubscriberZip              = client[11],
                    SubscribersSex             = client[12],
                    SubscribersSSNumber        = client[13],
                    SubscriberEmployerName     = " ",
                    SubscribersBirthDate       = client[15],
                    SubscriberMedicaidNumber   = " ",
                    EligibilityVerified        = client[17],
                    GuarantorPlan              = client[18],
                    SubscriberAssignOfBenefits = client[19],
                    CoordinationOfBenefits     = client[20],
                    SubscribersCoveredDays     = client[21],
                    MaximumCoveredDollars      = client[22],
                    SubscriberReleaseOfInfo    = client[23],
                    CustomizeGuarantorPlan     = client[24],
                    GuarantorOrderNumber       = client[25],
                };

                /*  Needs an Address 2
                 */
                if (guarantorSelectionObject.SubscriberAddress2 == string.Empty)
                {
                    guarantorSelectionObject.SubscriberAddress2 = " ";
                }

                //listOfArrayOfGuarantorSelectionObjectGuarantorSelectionObject.Add(guarantorSelectionObject);

                ArrayOfGuarantorSelectionObjectGuarantorSelectionObject listOfArrayOfGuarantorSelectionObjectGuarantorSelectionObject = new ArrayOfGuarantorSelectionObjectGuarantorSelectionObject();
                listOfArrayOfGuarantorSelectionObjectGuarantorSelectionObject.Add(guarantorSelectionObject);

                /*  Dictionary format is { ClientID, ArrayOfGuarantorSelectionObjectGuarantorSelectionObject }
                 */
                arrayOfGuarantorSelectionObjectGuarantorSelectionObjects.Add(client[0], listOfArrayOfGuarantorSelectionObjectGuarantorSelectionObject);
            }

            return arrayOfGuarantorSelectionObjectGuarantorSelectionObjects;
        }

        /// <summary>
        /// Imports financial eligabilty data into myAvatar.
        /// </summary>
        /// <param name="guarantorSelectionObject"> The GuarantorSelectionObjects </param>
        /// <remarks>
        /// Manages the data import process.
        /// </remarks>
        public static void Import(Dictionary<string, ArrayOfGuarantorSelectionObjectGuarantorSelectionObject> arrayOfGuarantorSelectionObjectGuarantorSelectionObjects, string systemCode, string username, string password, bool testMode, bool throttleImport)
        {
            var statusBox = new frmDuStatusBox();
            statusBox.Show();
            UpdateStatusBox(statusBox, Color.Black, Color.LightBlue, "Finance data import in progress...", "Starting...", false, "Done");

            var importCounter = 0;                                                                                       // Keeps track of what record is being imported
            var totalImports = arrayOfGuarantorSelectionObjectGuarantorSelectionObjects.Count;                                                            // Total number of records being imported.

            /*  Import each ClientAdmissionObject into myAvatar.
             */
            foreach (var arrayOfGuarantorSelectionObjectGuarantorSelectionObject in arrayOfGuarantorSelectionObjectGuarantorSelectionObjects)
            {
                AddCrossEpFinancialElig(systemCode, username, password, arrayOfGuarantorSelectionObjectGuarantorSelectionObject.Value, arrayOfGuarantorSelectionObjectGuarantorSelectionObject.Key, testMode);

                statusBox.SetStatus("Imported record " + (importCounter + 1) + " of " + totalImports);  // TODO counter++ +1?
                importCounter++;

                if (throttleImport)
                {
                    DuSystem.Pause(500);
                }
            }

            UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "Finance data import complete!", "Click \"Continue\"", true, "Continue");
;
            //return "[DEFAULT] Import complete.";
        }

        /// <summary> Adds cross episode financial eligibility data to Avatar. </summary>
        /// <param name="systemCode">               Avatar system code [SBOX/UAT/LIVE]                      </param>
        /// <param name="username">                 Avatar username                                         </param>
        /// <param name="password">                 Avatar password                                         </param>
        /// <param name="guarantorSelectionObject"> The object that contains the financial eligability data </param>
        /// <param name="clientID">                 The Client ID                                           </param>
        /// <returns> The web service response.   </returns>
        /// <remarks>
        /// Does the actual import into the specified Avatar environment.
        /// </remarks>
        public static string AddCrossEpFinancialElig(string systemCode, string userName, string password, ArrayOfGuarantorSelectionObjectGuarantorSelectionObject arrayOfGuarantorSelectionObjectGuarantorSelectionObject, string clientID, bool testMode)
        {
            switch (systemCode)
            {
                case "SBOX":
                    var SBOXSoapClient = new NTSTWEBSRV_CrossEpisodeFinancialEligibility_SBOX.CrossEpisodeFinancialEligibilitySoapClient();
                    var SBOXResponse   = new NTSTWEBSRV_CrossEpisodeFinancialEligibility_SBOX.WebServiceResponse();

                    if (!testMode)
                    {
                        var timeStamp = new DateTime(2006, 3, 21, 2, 0, 0).ToUniversalTime();
                        SBOXResponse = SBOXSoapClient.AddCrossEpFinancialElig(systemCode, userName, password, arrayOfGuarantorSelectionObjectGuarantorSelectionObject, clientID, null, timeStamp);
                    }

                    return SBOXResponse.Message;

                default:
                    return "ERROR";
            }
        }

        public static List<string> CheckForErrors(Dictionary<string, ArrayOfGuarantorSelectionObjectGuarantorSelectionObject> guarantorData)
        {
            var aList = new List<string>();
            aList.Add("No errors found");
            return aList;
        }

        /// <summary>
        /// Updates the statusBox
        /// </summary>
        /// <param name="statusBox">     The statusBox object </param>
        /// <param name="borderColor">   Background color (i.e. Color.Black) </param>
        /// <param name="backColor">     Background color (i.e. Color.White) </param>
        /// <param name="header">        Header text </param>
        /// <param name="status">        Status text </param>
        /// <param name="buttonEnabled"> Determines if the button is enabled [true/false] </param>
        /// <param name="buttonText">    Button text </param>
        /// <remarks>
        /// A nice, organized place to do all of the statusBox upating.
        /// </remarks>
        private static void UpdateStatusBox(frmDuStatusBox statusBox, Color borderColor, Color backColor, string header, string status, bool buttonEnabled, string buttonText)
        {
            statusBox.SetBorder(borderColor);
            statusBox.SetBackground(backColor);
            statusBox.SetHeader(header);
            statusBox.SetStatus(status);
            statusBox.ButtonEnabled(buttonEnabled);
            statusBox.ButtonText(buttonText);
            statusBox.Refresh();
        }
    }

}
